package com.company.entity;

public class LikeEntity {

}
