package com.company.enums;

public enum EntityType {
    CHANNEL,
    VIDEO
}
