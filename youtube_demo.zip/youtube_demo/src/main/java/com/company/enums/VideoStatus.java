package com.company.enums;

public enum VideoStatus {
    PUBLIC,
    PRIVATE
}
