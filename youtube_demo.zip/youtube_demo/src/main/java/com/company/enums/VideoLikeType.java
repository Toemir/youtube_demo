package com.company.enums;

public enum VideoLikeType {
    LIKE,
    DISLIKE
}
