package com.company.enums;

public enum PlaylistStatus {
    ACTIVE,
    BLOCK
}
