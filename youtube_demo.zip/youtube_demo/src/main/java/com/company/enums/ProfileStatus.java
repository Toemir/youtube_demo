package com.company.enums;

public enum ProfileStatus {
    ACTIVE,
    NON_ACTIVE,
    BLOCK
}
