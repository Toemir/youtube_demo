package com.company.enums;

public enum SubscriptionStatus {
    ACTIVE,
    DELETED
}
