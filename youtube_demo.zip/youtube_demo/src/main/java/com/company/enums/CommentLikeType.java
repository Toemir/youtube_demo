package com.company.enums;

public enum CommentLikeType {
    LIKE,
    DISLIKE
}
