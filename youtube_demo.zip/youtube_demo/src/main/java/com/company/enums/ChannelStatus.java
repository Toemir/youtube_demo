package com.company.enums;

public enum ChannelStatus {
    ACTIVE,
    BLOCK
}
