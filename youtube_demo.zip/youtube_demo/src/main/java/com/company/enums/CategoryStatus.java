package com.company.enums;

public enum CategoryStatus {
    ACTIVE,
    BLOCK
}
