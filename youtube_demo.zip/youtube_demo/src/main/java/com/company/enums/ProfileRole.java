package com.company.enums;

public enum ProfileRole {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_MODERATOR
}
