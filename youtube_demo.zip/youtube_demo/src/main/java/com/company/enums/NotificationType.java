package com.company.enums;

public enum NotificationType {
    ALL,
    PERSONALIZED,
    NONE
}
