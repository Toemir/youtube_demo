package com.company.dto;

import com.company.enums.ChannelStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChannelStatusDTO {
    private ChannelStatus status;
}
