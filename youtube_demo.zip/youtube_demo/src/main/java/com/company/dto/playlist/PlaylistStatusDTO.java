package com.company.dto.playlist;

import com.company.enums.PlaylistStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlaylistStatusDTO {
    private PlaylistStatus status;
}
